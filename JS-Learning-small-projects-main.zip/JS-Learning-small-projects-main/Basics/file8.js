// Inheritance
class MyClass {
    constructor(){
        
    }
}