import React from "react";

export default function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className=" p-4 shadow-md border border-gray-300 rounded-lg flex justify-center items-center text-lg font-medium bg-white h-auto">
      {children}
    </div>
  );
}
