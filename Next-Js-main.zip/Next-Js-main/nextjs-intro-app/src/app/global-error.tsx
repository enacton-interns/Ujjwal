"use client";
import "./global.css";
export default function GlobalError({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  return (
    
      <html lang="en">
        <body>
          <h1 className="text-4xl text-blue-500">{error.message}</h1>
        </body>
      </html>
  
  );
}
