export default function Profile() {
  return (
    <div>
      <h1>My Profile</h1>
    </div>
  );
}
