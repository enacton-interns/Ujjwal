import React from "react";

export default function page() {
  return (
    <div>
      <h1>Folder3</h1>
    </div>
  );
}
