export default function page() {
  return (
    <div>
      <h1>Private Folder</h1>
    </div>
  );
}
