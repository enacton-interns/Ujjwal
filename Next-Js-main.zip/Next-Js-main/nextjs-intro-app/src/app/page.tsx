import Link from "next/link";
import "./global.css";

export default function Home() {
  return (
    <div className="flex  flex-col">
      <h1 className="text-center">Welcome Home!</h1>
      <div className="flex flex-col gap-2 pl-4 ">
        <Link href="/blog">Blog</Link>
        <Link href="/products">Products</Link>
        <Link href="/articles/breaking-news-123?lang=en">Read in English</Link>
        <Link href="/articles/breaking-news-123?lang=es">Read in Spanish</Link>
        <Link href="/articles/breaking-news-123?lang=fr">Read in french</Link>
      </div>
    </div>
  );
}
