export default function DashboardDefaultPage() {
  return <div>Dashboard Default Page</div>;
}
