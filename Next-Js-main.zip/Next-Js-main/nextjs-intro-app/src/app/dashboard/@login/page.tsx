import React from "react";
import Card from "@/components/Card";
export default function LoginPage() {
  return <Card> Please login to continue </Card>;
}
