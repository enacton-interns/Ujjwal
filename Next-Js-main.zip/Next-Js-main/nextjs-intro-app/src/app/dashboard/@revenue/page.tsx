import Card from "@/components/Card";

export default function Revenue() {
  return <Card>Revenue</Card>;
}
