export default function UsersDefaultPage() {
  return <div>Users Default Page</div>;
}
