import Card from "@/components/Card";

export default function Users() {
  return <Card>Users</Card>;
}
