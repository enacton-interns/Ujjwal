export default function NotificationDefaultPage() {
  return <div>Notification Default Page</div>;
}
