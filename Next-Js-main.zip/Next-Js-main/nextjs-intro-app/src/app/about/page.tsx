export const metadata = {
  title: "About ",
  description: "about nextjs",
};
export default function About() {
  return <h1>About Me</h1>;
}
