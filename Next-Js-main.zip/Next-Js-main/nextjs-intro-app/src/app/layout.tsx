import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Next.js",

  description: "Genrated by next.js",
};
// const getRandomInteger = (num: number) => {
//   return Math.floor(Math.random() * num);
// };

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // const random = getRandomInteger(2);
  // if (random === 1) {
  //   throw new Error("Error in Global scope");
  // }
  return (
    <html lang="en">
      <body>
        <main>{children}</main>
      </body>
    </html>
  );
}
