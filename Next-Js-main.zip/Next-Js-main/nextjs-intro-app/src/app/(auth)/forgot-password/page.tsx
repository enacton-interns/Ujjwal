export default function Forgot() {
  return (
    <div>
      <h1>Forgot Password</h1>
    </div>
  );
}
