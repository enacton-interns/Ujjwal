import React from "react";

export default function Folder5() {
  return (
    <div>
      <h1>Folder 5</h1>
    </div>
  );
}
