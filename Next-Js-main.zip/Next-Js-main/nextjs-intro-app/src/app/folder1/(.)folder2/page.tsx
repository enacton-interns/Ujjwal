import Link from "next/link";
import React from "react";

export default function folder2InterceptedPage() {
  return (
    <div>
      <h1>(.) Intercepted folder2 Page</h1>{" "}
      <Link href={"/folder4"}>Folder 4</Link>
    </div>
  );
}
