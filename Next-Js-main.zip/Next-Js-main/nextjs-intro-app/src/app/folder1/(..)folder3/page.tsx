import React from "react";

export default function InterceptedFolder3() {
  return <div>(..)Intercepted folder3</div>;
}
