import Link from "next/link";
import React from "react";

export default function page() {
  return (
    <div>
      <Link href={"/folder5"}> Folder 5</Link>
    </div>
  );
}
