import React from "react";

export default function page() {
  return (
    <div>
      <h1>Intercepted Folder5</h1>
    </div>
  );
}
