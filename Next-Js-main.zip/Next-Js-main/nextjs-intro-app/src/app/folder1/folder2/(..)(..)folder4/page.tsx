import React from "react";

export default function page() {
  return (
    <div>
      <h1>Intercepted Folder 4</h1>
    </div>
  );
}
