import Link from "next/link";
import React from "react";

export default function Folder1() {
  return (
    <div>
      <h1>Folder1</h1>
      <Link href={"/folder1/folder2"}>Folder 2</Link>
      <Link href={"/folder3"}>Folder3</Link>{" "}
      <Link href={"/folder4"}>Folder 4</Link>
    </div>
  );
}
