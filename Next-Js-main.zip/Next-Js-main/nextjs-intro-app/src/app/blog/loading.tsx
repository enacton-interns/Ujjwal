export default function LoadingBlog() {
  return <h1>Blog is Loading....</h1>;
}
