import React from 'react'

export default function First() {
  return (
    <div>
      <h1> First Blog  </h1>
    </div>
  )
}
