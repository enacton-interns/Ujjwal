export default function Second() {
  return (
    <div>
      <h1>Second Blog</h1>
    </div>
  );
}
