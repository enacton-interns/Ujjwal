import { notFound, redirect } from "next/navigation";
type ParamsType = {
  params: { productId: string; reviewId: string };
};

const getRandomInteger = (num: number) => {
  return Math.floor(Math.random() * num);
};
export default function ProductReview({ params }: ParamsType) {
  const random = getRandomInteger(2);
  if (random === 1) {
    throw new Error("Error in Product Review!");
  }
  const { productId, reviewId } = params;
  if (parseInt(reviewId) > 1000) {
    // notFound();
    redirect("/products");
  }
  return (
    <div>
      <h1>
        Review is {reviewId} for product {productId}
      </h1>
    </div>
  );
}
