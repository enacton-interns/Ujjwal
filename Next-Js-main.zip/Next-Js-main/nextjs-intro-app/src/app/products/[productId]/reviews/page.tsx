export default function Reviews() {
  return (
    <div>
      <h1>Reviews</h1>
      <h2>Reviews for Products 1</h2>

      <h2>Reviews for Products 2</h2>

      <h2>Reviews for Products 3</h2>
    </div>
  );
}
