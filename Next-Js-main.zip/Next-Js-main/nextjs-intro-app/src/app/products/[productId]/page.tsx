type Props = {
  params: { productId: string };
};
export async function generateMetadata({ params }: Props) {
  const id =  params.productId;
  return { title: `Product ${id}` };
}
export default async function ProductDetails({ params }: Props) {
  const productId =  params.productId;
  return <h1>Details about product {productId}</h1>;
}
