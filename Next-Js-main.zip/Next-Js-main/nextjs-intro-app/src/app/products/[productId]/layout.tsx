export default function layout({ children }: { children: React.ReactNode }) {
  const random = getRandomInteger(2);
  if (random === 1) {
    throw new Error("Error in Product Id!");
  }
  return (
    <div>
      <h1>Review</h1>
      {children}
    </div>
  );
}
const getRandomInteger = (num: number) => {
  return Math.floor(Math.random() * num);
};
