import React from "react";

export default function ProfilePage() {
  return (
    <div>
      <h1>profile page</h1>
    </div>
  );
}
