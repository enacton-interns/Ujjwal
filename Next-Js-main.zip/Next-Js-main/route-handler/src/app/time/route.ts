export const revalidate = 90;
export async function GET() {
  const time = new Date().toLocaleTimeString();
  return new Response(` <h1>  Time:  ${time} </h1>`, {
    headers: {
      "Content-Type": "text/html",
    },
  });
}
