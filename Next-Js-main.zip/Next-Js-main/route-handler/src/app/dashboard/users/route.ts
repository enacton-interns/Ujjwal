export async function GET() {
  return new Response("Dashboard Users data");
}
