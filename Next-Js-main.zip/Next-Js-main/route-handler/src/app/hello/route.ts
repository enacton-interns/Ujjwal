export async function GET() {
  return new Response("Hello World");
}
