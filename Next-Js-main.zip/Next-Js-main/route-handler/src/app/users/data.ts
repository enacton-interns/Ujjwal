type userdatatype = {
  id: number;
  username: string;
  email: string;
  content: string;
}[];
const userdata: userdatatype = [
  {
    id: 1,
    username: "Alice",
    email: "alice@example.com",
    content: "This is an awesome post! Really enjoyed it.",
  },
  {
    id: 2,
    username: "Bob",
    email: "bob@example.com",
    content: "I have a question about the second paragraph.",
  },
  {
    id: 3,
    username: "Charlie",
    email: "charlie@example.com",
    content: "Thanks for sharing this, very informative.",
  },
  {
    id: 4,
    username: "Diana",
    email: "diana@example.com",
    content: "Could you provide more examples next time?",
  },
  {
    id: 5,
    username: "Ethan",
    email: "ethan@example.com",
    content: "I disagree with one point mentioned here.",
  },
  {
    id: 6,
    username: "Fiona",
    email: "fiona@example.com",
    content: "Great explanation, helped me a lot!",
  },
  {
    id: 7,
    username: "George",
    email: "george@example.com",
    content: "Can someone clarify the last section?",
  },
  {
    id: 8,
    username: "Hannah",
    email: "hannah@example.com",
    content: "Looking forward to your next post.",
  },
  {
    id: 9,
    username: "Ian",
    email: "ian@example.com",
    content: "Interesting perspective, thanks for sharing!",
  },
  {
    id: 10,
    username: "Julia",
    email: "julia@example.com",
    content: "This cleared up a lot of confusion for me.",
  },
];
export default userdata;
