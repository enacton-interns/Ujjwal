import { NextRequest } from "next/server";
import userdata from "./data";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get("query")?.toLowerCase() || "";
  const filteredUsers = query
    ? userdata.filter((user) => user.content?.toLowerCase().includes(query))
    : userdata;
  return Response.json(filteredUsers);
}

export async function POST(request: Request) {
  const body = await request.json();
  const newUser = {
    id: userdata.length + 1,
    username: body.username ?? "Julia",
    email: body.email ?? "julia@example.com",
    content: body.content ?? "This cleared up a lot of confusion for me.",
  };
  userdata.push(newUser);
  return Response.json(newUser);
}
