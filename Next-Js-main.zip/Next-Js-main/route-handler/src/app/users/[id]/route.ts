import userdata from "../data";

type Props = {
  params: Promise<{ id: string }>;
};
export async function GET(request: Request, { params }: Props) {
  const { id } = await params;
  const user = userdata.find((user) => user.id === Number(id));
  if (!user) {
    return Response.json({ error: "User not found" }, { status: 404 });
  }
  return Response.json(user);
}

export async function PATCH(request: Request, { params }: Props) {
  const { id } = await params;
  const body = await request.json();
  const { content } = body;
  const index = userdata.findIndex((user) => user.id === Number(id));
  if (index >= 0) userdata[index].content = content;
  return Response.json(userdata);
}

export async function DELETE(request: Request, { params }: Props) {
  const { id } = await params;
  const index = userdata.findIndex((user) => user.id === Number(id));
  const user = userdata[index];
  userdata.splice(index, 1);
  // const userData = userdata.filter((user) => user.id !== Number(id));
  return Response.json({ user, userdata });
}
